# PragnaKongara-Real-mart-sales-Dashboard
Designed an interactive Dashboard to Visualise the Sales of Real Mart Data – Tech Stack includes Power BI Desktop, Excel, Kaggle
